import StarIcon from '@mui/icons-material/Star';
import VerifiedIcon from '@mui/icons-material/Verified';
import styled from 'styled-components';
function Combos(){
    return(<Design><div>
    <div class="main-content">
        <img class="main w-100"src="https://images.mamaearth.in/wysiwyg/FLAT400/Website_wwow.jpg?fit=scale&w=&h=&q="></img>
        </div>
        <div class="category d-flex col-12 ">
           
          
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
           
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          </div>

          <div class="category   d-flex col-12 ">
        
          
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          </div>
          <div class="category   d-flex col-12 ">
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          <div class="box border">
             <img class="img1" src="https://images.mamaearth.in/catalog/product/f/o/fop-with-ingredients_2.jpg?format=auto&width=400&height=400"></img>
             <h6 class="ms-3 mb-0">Natural Mosquito Repellent Gel - 50 ml (Pack of 3)</h6>
             <p class="ms-3 mt-0 mb-0 text-success">DEET Free | Protects from Dengue, Malaria & Chikungunya</p>
             <div class="d-flex">
             <h4 class="ms-3 m-0 mb-3 text-warning">₹297.00</h4>
             <StarIcon class="star ms-2 mb-2"></StarIcon>
             <p class="rating m-1 ms-0 p-1">3.4</p>
             <VerifiedIcon class="rate1 ms-1 mb-2"></VerifiedIcon>
             <p class="rating m-1 me-1 p-1">345 Ratings</p>
             </div>
             <button class="btn btn-primary cart1 ">ADD TO CART</button>
          </div>
          </div> 
    </div>
    </Design>)
}
export default Combos;

const Design=styled.div`
.navbar{
    height: 100px;
}
.primary-navbar{
    height: 50px;
}
.icon{
    width:150px;
}
.secondary-navbar *{
    height: 50px;
    text-decoration: none;
    margin:5px;
    font-size: medium;  
}
.search input{
    width:601px;
    border-radius: 20px;
    height:52px;
}
.icon2{
    width: 150px;
    margin-left: 5px;
}
.cart{
    width: 25px;
}
.user{
    width: 30px;
}
.category{
    width:100%;
    height:550px; 
}
.box{
    width:25%;
    height:450px;
    margin:3px;  
}
.main-content{
    width:100%;
}
.img1{
    width: 200px;
    margin: 20px;
}
.cart1{
    width: 295px;   
}
.star{
    width:15px;
}
.rating{
    font-size: small;
}
.rate1{
    width: 15px;
}
`